<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Kontakt - Rabljeni Auta</title>
    <link href="default.css" rel="stylesheet" type="text/css" media="all">
</head>
<body>
<div id="wrapper">
    <div id="menu-wrapper">
        <div id="menu" class="container">
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li><a href="ponuda.php">Ponuda</a></li>
                <li class="current_page_item"><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </div>
    </div>
    <div id="page" class="container">
        <div id="content">
            <div class="title">
                <h1>Kontaktirajte nas</h1>
                <span class="byline">Ovdje smo za vas!</span>
            </div>
            <div class="contact-container">
                <div class="contact-info">
                    <?php
                    $json = file_get_contents('kontakt.json');
                    $data = json_decode($json, true);
                    echo '<p>Adresa: ' . $data['Adresa'] . '</p>';
                    echo '<p>Telefon: ' . $data['Telefon'] . '</p>';
                    ?>
                </div>
                <div class="map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2797.123114301581!2d16.7786581!3d45.4874655!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x476703c685927957%3A0xca1d7d4b1335b90e!2sUl.%20Milke%20Trnine%2021%2C%2044320%2C%20Kutina!5e0!3m2!1shr!2shr!4v1717427871322!5m2!1shr!2shr" width="1000" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>
        <div id="sidebar">
            <div class="box2">
                <div class="title">
                    <h2>Navigacija</h2>
                </div>
                <ul class="style2">
                    <li><a href="index.php">Početna</a></li>
                    <li><a href="ponuda.php">Ponuda</a></li>
                    <li><a href="kontakt.php">Kontakt</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div id="copyright" class="container">
    <p>© Need4Car 2024.</p>
</div>
</body>
</html>
