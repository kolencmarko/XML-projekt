<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Početna - auti</title>
    <link href="default.css" rel="stylesheet" type="text/css" media="all">
</head>
<body>
<div id="wrapper">
    <div id="menu-wrapper">
        <div id="menu" class="container">
            <ul>
                <li class="current_page_item"><a href="index.php">Početna</a></li>
                <li><a href="ponuda.php">Ponuda</a></li>
                <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </div>
    </div>
    <div id="page" class="container">
        <div id="content">
            <div class="title">
                <h1>Need4Car</h1>
                <span class="byline">Zagarantirano najbolja ponuda rabljenih auta u gradu</span>
            </div>
            <p>Pronađite svoj idealan rabljeni automobil po povoljnim cijenama. Nudimo širok izbor automobila svih marki i modela. Dođi, oduševi se i odvezi se doma svojim novim autom!</p>
            <img src="goodman.jpg" alt="goodman" class="goodman">
        </div>
        <div id="sidebar">
            <div class="box2">
                <div class="title">
                    <h2>Navigacija</h2>
                </div>
                <ul class="style2">
                    <li><a href="index.php">Početna</a></li>
                    <li><a href="ponuda.php">Ponuda</a></li>
                    <li><a href="kontakt.php">Kontakt</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div id="copyright" class="container">
    <p>© Need4Car 2024.</p>
</div>
</body>
</html>
