<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Ponuda - Rabljeni Auta</title>
    <link href="default.css" rel="stylesheet" type="text/css" media="all">
</head>
<body>
<div id="wrapper">
    <div id="menu-wrapper">
        <div id="menu" class="container">
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li class="current_page_item"><a href="ponuda.php">Ponuda</a></li>
                <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </div>
    </div>
    <div id="page" class="container">
        <div id="content">
            <div class="title">
                <h1>Naša ponuda rabljenih automobila</h1>
            </div>
            <div class="car-container">
            <?php
            $xml = simplexml_load_file('cars.xml') or die('Error: Cannot create object');
            foreach ($xml->car as $car) {
                echo '<div class="car">';
                echo '<h3>' . $car->name . '</h3>';
                echo '<img src="' . $car->image . '" alt="' . $car->name . '">';
                echo '<p>Cijena: <b>' . $car->price . '</b></p>';
                echo '<p>Godina: ' . $car->year . '</p>';
                echo '<p>Kilometraža: ' . $car->kilometraza . '</p>';
                echo '<span class="byline">Nazovi</span>';
                echo '</div>';
            }
            ?>
            </div>
        </div>
        <div id="sidebar">
            <div class="box2">
                <div class="title">
                    <h2>Navigacija</h2>
                </div>
                <ul class="style2">
                    <li><a href="index.php">Početna</a></li>
                    <li><a href="ponuda.php">Ponuda</a></li>
                    <li><a href="kontakt.php">Kontakt</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div id="copyright" class="container">
    <p>© Need4Car 2024.</p>
</div>
</body>
</html>
